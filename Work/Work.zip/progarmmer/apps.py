from django.apps import AppConfig


class ProgarmmerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'progarmmer'
