from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Resume)
admin.site.register(Project)
admin.site.register(Language)
admin.site.register(Language_persian)
admin.site.register(Professional_skill)
admin.site.register(Professional_skill_persian)
admin.site.register(Abuot)